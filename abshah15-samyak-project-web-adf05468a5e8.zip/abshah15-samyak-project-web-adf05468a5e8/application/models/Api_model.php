<?php

class Api_model extends MY_Model
{
	public function __construct() {
        parent::__construct(); 
    }
	
	function check_login($email_or_mobile,$password)
	{
		return  $this->db
				->where("(phone='".$email_or_mobile."' OR email='".$email_or_mobile."')")	
				->get_where('users',array('password' => md5($password),'is_delete' => 'n'))
				->row();
	}

	function get_country()
	{
		return  $this->db
				->get('country')
				->result_array();
	}

	function get_category()
	{
		return  $this->db
				->get_where('categories',array('is_active' => 'y'))
				->result_array();
	}

	
}