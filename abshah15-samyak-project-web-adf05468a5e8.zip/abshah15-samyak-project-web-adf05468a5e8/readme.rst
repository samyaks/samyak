###################
Samyak Project
###################

Project backend is develop in Php using CI Frameworks. It connect with the plaid apis and get the trascations of a plaid user who has register in our application.We have use below plaid api document for development:

https://plaid.com/docs/
