<?php

class MY_Model extends CI_Model {

    public $table;
    public $primary_key;
    public $table_prefix;

    public function __construct() {
        parent::__construct();
        $this->table_prefix = '';
    }

    /**
     * Private function to return query result
     * @param CI query object $query
     * @param string $result
     * @return mixed
     */
    private function return_result($query, $result = 'result') {
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return [];
        }
    }

    /**
     * This function return all data of particular table
     * @param string $table table name
     * @param string $result result to be return object (result) | array (result_array)
     * @return array | array of object | Empty array
     */
    public function get_all($result = 'result', $table = '') {
        $table = (empty($table)) ? $this->table : $table;
        $query = $this->db->get($table);
        return $this->return_result($query, $result);
    }

    /**
     * This function return all data of particular table with where condition all with AND logic ( array ) or string
     * @param string $table table name
     * @param string | array $where
     * @param string $result result to be return object (result) | array (result_array)
     * @return array | array of object | Empty array
     * @return type
     */
    public function get_where($where = [], $result = 'result', $table = '') {
        $table = (empty($table)) ? $this->table : $table;
        $this->db->where($where);
        $query = $this->db->get($table);
        return $this->return_result($query, $result);
    }

    public function get_where_single($where = [], $table = '') {
        $table = (empty($table)) ? $this->table : $table;
        $this->db->where($where);
        $query = $this->db->get($table);
        return $query->row(1);
    }

    public function get_where_count($where = [], $table = '') {
        $result = 'result'; 
        $table = (empty($table)) ? $this->table : $table;
        $this->db->where($where);
        $query = $this->db->get($table);
        return $query->num_rows();
    }


    public function get_where_join($select="*",$where = [], $join = [], $table = '') {

        $result = 'result';
        $table = (empty($table)) ? $this->table : $table;
        $this->db->select($select);
        $this->db->where($where);
        foreach ($join as $key => $value) { 
            $this->db->join("$key","$value");
        }
        $query = $this->db->get($table);
        return $this->return_result($query, $result);
    }

    /**
     * 
     * @param type $column
     * @param type $where
     * @param type $result
     * @param type $limit
     * @param type $offset
     * @param type $table
     * @param type $order_by
     * @param type $order
     * @return type
     */
    public function get_what_where_how($column = '*', $where = [], $result = 'row', $limit = '', $offset = '', $table = '', $order_by = '', $order = '') {
        $table = (empty($table)) ? $this->table : $table;
        $this->db->select($column);
        if (!empty($where)) {
            $this->db->where($where);
        }
        if (!empty($limit) && empty($offset)) {
            $this->db->limit($limit);
        }
        if (!empty($limit) && !empty($offset)) {
            $this->db->limit($limit, $offset);
        }
        if (!empty($order_by)) {
            $this->db->order_by($order_by, $order);
        }
        $query = $this->db->get($table);
        return $this->return_result($query, $result);
    }

    /**
     * 
     * @param type $data
     * @param type $table
     * @return type
     */
    public function insert_data($data, $table = '') {
        $table = (empty($table)) ? $this->table : $table;
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    /**
     * 
     * @param type $data
     * @param type $where
     * @param type $table
     * @return boolean
     */
    public function update_data($data, $where = '', $table = '') {
        $table = (empty($table)) ? $this->table : $table;
        $this->db->where($where);
        $this->db->update($table, $data);
        return true;
    }

    /**
     * 
     * @param type $where
     * @param type $table
     * @return boolean
     */
    public function delete_hard($where, $table = '') {
        $table = (empty($table)) ? $this->table : $table;
        $this->db->where($where);
        $this->db->delete($table);
        return true;
    }

    /**
     * 
     * @param type $where
     * @param type $table
     * @return boolean
     */
    public function delete_soft($where, $table = '') {
        $table = (empty($table)) ? $this->table : $table;
        $this->db->where($where);
        $data = ['is_delete' => 1];
        $this->db->update($table, $data);
        return true;
    }

    public function is_unique($field, $value, $except, $table = '') {
        $table = (empty($table)) ? $this->table : $table;
        $this->db->select($field);
        $this->db->where($field, $value);
        $this->db->where($except);
        $query = $this->db->get($table);

        if ($query->num_rows() > 0) {
            return false;
        } else {
            return true;
        }
    }
    
    public function last_query(){
        return $this->db->last_query();
    }

}