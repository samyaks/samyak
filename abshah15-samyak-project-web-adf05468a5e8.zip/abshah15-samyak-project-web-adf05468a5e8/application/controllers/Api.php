<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Content-Type: application/json');

class Api extends CI_COntroller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Api_model','api_obj');
	}

	function register()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			
			$this->form_validation->set_rules('email', 'email', 'required|is_unique[users.email]');
			$this->form_validation->set_rules('phone', 'phone', 'required|is_unique[users.phone]');
			$this->form_validation->set_rules('password', 'password', 'required');
			$this->form_validation->set_rules('country_code', 'country_code', 'required');
			$this->form_validation->set_rules('country', 'country', 'required');
			$this->form_validation->set_rules('fcm_token', 'fcm_token', 'required');
			
			if ($this->form_validation->run() == FALSE) {
				$error = implode(",", $this->form_validation->error_array());
				$error = explode(",", $error);
				$json = array("status" => 0,"message" =>  $error[0]);
			}
			else
			{
				$data = array(
					'email' => $this->input->post('email'),
					'phone' => $this->input->post('phone'),
					'password' => md5($this->input->post('password')),
					'country_code' => $this->input->post('country_code'),
					'country' => $this->input->post('country'),
					'fcm_token' => $this->input->post('fcm_token')
				);

				$user_id = $this->api_obj->insert_data($data,'users');
				$json = array("status" => 1,"message" => "User Register Successfully");
			}
		}else
		{
			$json = array("status" => 0,"message" => "Please set valid request method");
		}

		echo json_encode($json);
	}

	
	function login()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$this->form_validation->set_rules('email_or_mobile', 'email_or_mobile', 'required');
			$this->form_validation->set_rules('password', 'password', 'required');
			$this->form_validation->set_rules('fcm_token', 'fcm_token', 'required');

			if ($this->form_validation->run() == FALSE) {
				$error = implode(",", $this->form_validation->error_array());
				$error = explode(",", $error);
				$json = array("status" => 0,"message" =>  $error[0]);
			}
			else
			{
				$result = $this->api_obj->check_login($this->input->post('email_or_mobile'),$this->input->post('password'));
				if (!empty($result)) {
					$user_id = $result->user_id;
				
					
					
					$json = array("status" => 1,"message" => "Login Successfully","data" => $result);
					
				}else{
					$json = array("status" => 0,"message" => "Please Enter Correct Credentials");
				}
			}
		}else
		{
			$json = array("status" => 0,"message" => "Please set valid request method");
		}

		echo json_encode($json);
	}

	function add_plaid_fields()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			
			$this->form_validation->set_rules('client_id', 'client_id', 'required');
			$this->form_validation->set_rules('secret', 'secret', 'required');
			$this->form_validation->set_rules('public_key', 'public_key', 'required');
			$this->form_validation->set_rules('user_id', 'user_id', 'required');
			
			if ($this->form_validation->run() == FALSE) {
				$error = implode(",", $this->form_validation->error_array());
				$error = explode(",", $error);
				$json = array("status" => 0,"message" =>  $error[0]);
			}
			else
			{
				$client_id =  $this->input->post('client_id');
				$secret =  $this->input->post('secret');
				$public_key =  $this->input->post('public_key');
				$user_id =  $this->input->post('user_id');

				

				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://sandbox.plaid.com/institutions/get",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => "{\n  \"client_id\": \"$client_id\",\n  \"secret\": \"$secret\",\n  \"count\": 200,\n  \"offset\": 0\n}",
				  CURLOPT_HTTPHEADER => array(
				    "cache-control: no-cache",
				    "content-type: application/json",
				    "postman-token: 47d74eec-7076-1b62-beed-899705247576"
				  ),
				));

				 $response1 = curl_exec($curl);
				 // echo $response1;exit;
				$response = json_decode($response1);
				// $err = curl_error($curl);

				curl_close($curl);

				
				if((array_key_exists("error_message",$response)))
				{
					$json = array("status" => 0,"message" => $response->error_message);
				}
				else{

					$data = array(
						'client_id' => $client_id,
						'secret' => $secret,
						'public_key' => $public_key,
						'user_id' => $user_id
					);
					$get_client_id_count = $this->api_obj->get_where_count(array('client_id' => $client_id),'plaid_fields');
					if($get_client_id_count == 0)
					{
						$this->api_obj->insert_data($data,'plaid_fields');
					}


					foreach ($response->institutions as $key => $value) {
						$institution_id = $value->institution_id;
						$name = $value->name;
						$products = implode(',',$value->products);
						
						$get_count = $this->api_obj->get_where_count(array('institution_id' => $institution_id),'plaid_access_tokens');
						if($get_count == 0)
						{
							
							$curl = curl_init();

							curl_setopt_array($curl, array(
							  CURLOPT_URL => "https://sandbox.plaid.com/sandbox/public_token/create",
							  CURLOPT_RETURNTRANSFER => true,
							  CURLOPT_ENCODING => "",
							  CURLOPT_MAXREDIRS => 10,
							  CURLOPT_TIMEOUT => 30,
							  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
							  CURLOPT_CUSTOMREQUEST => "POST",
							  CURLOPT_POSTFIELDS => "{\n  \"public_key\": \"$public_key\",\n  \"institution_id\": \"$institution_id\",\n  \"initial_products\":[\n\"transactions\"]\n  \n}",
							  CURLOPT_HTTPHEADER => array(
							    "cache-control: no-cache",
							    "content-type: application/json",
							    "postman-token: 47d74eec-7076-1b62-beed-899705247576"
							  ),
							));

							$response_public_token1 = curl_exec($curl);
							$response_public_token = json_decode($response_public_token1);
							// print_r($response_public_token);
							if(isset($response_public_token->public_token))
							{
								$public_token = $response_public_token->public_token;
								curl_close($curl);
									
								$curl = curl_init();

								curl_setopt_array($curl, array(
								  CURLOPT_URL => "https://sandbox.plaid.com/item/public_token/exchange",
								  CURLOPT_RETURNTRANSFER => true,
								  CURLOPT_ENCODING => "",
								  CURLOPT_MAXREDIRS => 10,
								  CURLOPT_TIMEOUT => 30,
								  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
								  CURLOPT_CUSTOMREQUEST => "POST",
								  CURLOPT_POSTFIELDS => "{\n  \"client_id\": \"$client_id\",\n  \"secret\": \"$secret\",\n  \"public_token\": \"$public_token\"}",
								  CURLOPT_HTTPHEADER => array(
								    "cache-control: no-cache",
								    "content-type: application/json",
								    "postman-token: 47d74eec-7076-1b62-beed-899705247576"
								  ),
								));

								$response_access_token1 = curl_exec($curl);
								$response_access_token = json_decode($response_access_token1);
								$access_token = $response_access_token->access_token;
								curl_close($curl);

								$data1 = array(
									'institution_id' => $institution_id,
									'name' => $name,
									'products' => $products,
									'user_id' => $user_id,
									'access_token' => $access_token,
									'public_token' => $public_token
								);

								$insert_id_plaid_access_token = $this->api_obj->insert_data($data1,'plaid_access_tokens');
							}
						}
					}

					$json = array("status" => 1,"message" => "Insert Successfully");
				}
			}
		}else
		{
			$json = array("status" => 0,"message" => "Please set valid request method");
		}

		echo json_encode($json);
	}

	function get_transaction()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			
			$this->form_validation->set_rules('user_id', 'user_id', 'required');
			$this->form_validation->set_rules('start_date', 'start_date', 'required');
			$this->form_validation->set_rules('end_date', 'end_date', 'required');
			$this->form_validation->set_rules('plaid_access_token_id', 'plaid_access_token_id', 'required');
			
			if ($this->form_validation->run() == FALSE) {
				$error = implode(",", $this->form_validation->error_array());
				$error = explode(",", $error);
				$json = array("status" => 0,"message" =>  $error[0]);
			}
			else
			{
				$user_id =  $this->input->post('user_id');
				$start_date =  $this->input->post('start_date');
				$end_date =  $this->input->post('end_date');
				$plaid_access_token_id =  $this->input->post('plaid_access_token_id');
				$user_details = $this->api_obj->get_where_single(array('user_id'=>$user_id,'plaid_access_token_id'=>$plaid_access_token_id),'plaid_access_tokens');
				$client_details = $this->api_obj->get_where_single(array('user_id'=>$user_id),'plaid_fields');

				$client_id = $client_details->client_id;
				$secret = $client_details->secret;
				$access_token = $user_details->access_token;
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://sandbox.plaid.com/transactions/get",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => "{\n  \"client_id\": \"$client_id\",\n  \"secret\": \"$secret\",\n  \"access_token\": \"$access_token\",\n  \"start_date\": \"$start_date\",\n  \"end_date\": \"$end_date\"}",
				  CURLOPT_HTTPHEADER => array(
				    "cache-control: no-cache",
				    "content-type: application/json",
				    "postman-token: 47d74eec-7076-1b62-beed-899705247576"
				  ),
				));

				 $response1 = curl_exec($curl);
				 // echo $response1;exit;
				$response = json_decode($response1);
				// $err = curl_error($curl);

				curl_close($curl);

				$json = array("status" => 1,"message" => "Transaction List","data" => $response);		
			}
		}else
		{
			$json = array("status" => 0,"message" => "Please set valid request method");
		}

		echo json_encode($json);
	}

	function get_bank_list()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			
			$this->form_validation->set_rules('user_id', 'user_id', 'required');
			
			if ($this->form_validation->run() == FALSE) {
				$error = implode(",", $this->form_validation->error_array());
				$error = explode(",", $error);
				$json = array("status" => 0,"message" =>  $error[0]);
			}
			else
			{
				$user_id =  $this->input->post('user_id');
				
				$bank_details = $this->api_obj->get_where(array('user_id'=>$user_id),'','plaid_access_tokens');
			
				$json = array("status" => 1,"message" => "Transaction List","data" => $bank_details);		
			}
		}else
		{
			$json = array("status" => 0,"message" => "Please set valid request method");
		}

		echo json_encode($json);
	}

	function get_country()
	{
		if ($this->input->server('REQUEST_METHOD') == 'GET')
		{
			$country = $this->api_obj->get_country();
		
			$json = array("status" => 1,"message" => "Country List","data" => $country);
		}else
		{
			$json = array("status" => 0,"message" => "Please set valid request method");
		}

		echo json_encode($json);
	}

	function get_categories()
	{
		if ($this->input->server('REQUEST_METHOD') == 'GET')
		{
			$category = $this->api_obj->get_category();
		
			$json = array("status" => 1,"message" => "Category List","data" => $category);
		}else
		{
			$json = array("status" => 0,"message" => "Please set valid request method");
		}

		echo json_encode($json);
	}
}
